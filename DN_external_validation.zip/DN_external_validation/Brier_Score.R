# ============================================================
# Logistic回归模型：基于14个预测因子预测住院死亡风险
# 计算Brier评分和校准截距
# ============================================================
if (!require("rms",quietly = TRUE)){
  #如果未安装，则使用install.packages函数安装
  install.packages("rms")}
# 加载必要的包
library(dplyr)
library(rms)      # 用于校准曲线和校准截距计算

# 设置工作路径
setwd("E:/rtest")

# 1. 读取数据
# 请根据实际文件名调整，这里假设文件名为 IMP.data.all.long2_2.csv 或 .RData
# 如果是CSV文件：
data <- read.csv("IMP.data.all.long2_2.csv", header = TRUE)
# 如果是RData文件：load("IMP.data.all.long2_2.RData")，然后指定数据框名称

# 2. 检查数据结构和变量名
str(data)
head(data)

# 3. 定义预测变量和目标变量
# 注意：根据您提供的变量列表，修正拼写错误
features <- c("Age", "Hemoglobin", "Potassium", "Chloride", 
              "Magnesium", "Albumin", "International_normalized_ratio", 
              "Blood_urea_nitrogen", "Renal_replacement_therapy", 
              "Severe_liver_disease", "Malignant_cancer", 
              "Cardiovascular_disease", "Congestive_heart_failure")

# 目标变量：住院死亡标志（请根据实际列名修改，例如 hosp_mort, status, death 等）
# 假设目标变量名为 "hosp_mort"，死亡=1，存活=0
target <- "status"

# 检查所有变量是否存在于数据中
if (!all(features %in% colnames(data))) {
  stop("部分预测变量不在数据中，请检查列名拼写")
}
if (!target %in% colnames(data)) {
  stop(paste("目标变量", target, "不在数据中，请指定正确的列名"))
}

# 提取完整数据并删除缺失值（或者使用多重插补，这里为简单起见使用完整案例分析）
data_complete <- data[, c(features, target)] %>% na.omit()
cat("完整样本量:", nrow(data_complete), "\n")

# 将性别转换为因子（假设gender: 1=男, 0=女或类似）
data_complete$gender <- as.factor(data_complete$gender)

# 4. 划分训练集和测试集（70%训练，30%测试）
set.seed(123)
train_idx <- sample(1:nrow(data_complete), size = 0.7 * nrow(data_complete), replace = FALSE)
train_data <- data_complete[train_idx, ]
test_data <- data_complete[-train_idx, ]

# 5. 构建Logistic回归模型
formula <- as.formula(paste(target, "~", paste(features, collapse = " + ")))
model <- glm(formula, data = train_data, family = binomial(link = "logit"))

# 模型摘要
summary(model)

# 6. 在测试集上预测死亡概率
pred_prob <- predict(model, newdata = test_data, type = "response")
obs <- test_data[[target]]

# 7. 计算Brier评分
brier_score <- mean((pred_prob - obs)^2)
cat("\n========== 模型性能 ==========\n")
cat("Brier Score:", round(brier_score, 4), "\n")

# 8. 计算校准截距（Calibration Intercept）
# 方法：以实际结局为因变量，logit(预测概率)为偏移量，拟合广义线性模型，截距即为校准截距
logit_pred <- log(pred_prob / (1 - pred_prob))
calib_model <- glm(obs ~ offset(logit_pred), family = binomial)
calibration_intercept <- coef(calib_model)[1]
cat("Calibration Intercept:", round(calibration_intercept, 4), "\n")

# 可选：同时计算校准斜率（标准方法：glm(obs ~ logit_pred, family=binomial)）
calib_slope_model <- glm(obs ~ logit_pred, family = binomial)
cat("Calibration Slope:", round(coef(calib_slope_model)[2], 4), "\n")
cat("Calibration Intercept (from logistic on logit):", round(coef(calib_slope_model)[1], 4), "\n")

# 9. 使用rms包绘制校准曲线（可选）
# 加载必要的包
library(rms)
library(ggplot2)

# 假设之前已完成数据准备和模型拟合（train_data, test_data, model）
# 如果还没有拟合模型，请先运行之前的建模代码

# 方法一：使用 lrm 并设置 x=TRUE, y=TRUE（推荐）
dd <- datadist(train_data)
options(datadist = "dd")

# 重新拟合 lrm 模型，务必加上 x=TRUE, y=TRUE
lrm_model <- lrm(formula, data = train_data, x = TRUE, y = TRUE)

# 进行校准（ bootstrap 重采样， B=200 可能较慢，可适当减小如 B=100 ）
cal <- calibrate(lrm_model, method = "boot", B = 100, data = train_data)

# 绘制校准曲线
plot(cal, xlab = "Predicted Probability", ylab = "Observed Probability",
     main = "Calibration Curve (Bootstrap)", 
     subtitles = FALSE, 
     cex = 0.8, 
     col = "blue")

# 可选：在图上添加理想线（45度线）
abline(0, 1, lty = 2, col = "red")external_validation_Brier Score

# 10. 输出汇总结果
results <- data.frame(
  Metric = c("Brier Score", "Calibration Intercept", "Calibration Slope"),
  Value = c(brier_score, calibration_intercept, coef(calib_slope_model)[2])
)
print(results)

# 可选：保存模型和预测结果
saveRDS(model, "logistic_model.rds")
 write.csv(data.frame(obs = obs, pred = pred_prob), "test_predictions.csv", row.names = FALSE)
 
 